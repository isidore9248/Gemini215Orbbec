// Copyright (c) Orbbec Inc. All Rights Reserved.
// Licensed under the MIT License.

#ifdef __cplusplus
extern "C" {
#endif

#define ESC_KEY 27

#ifdef __cplusplus
}
#endif
